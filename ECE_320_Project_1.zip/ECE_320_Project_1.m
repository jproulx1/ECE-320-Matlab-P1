figure (1)
nb3=0:15;
b3=[1 1 -1 zeros(1,13)];
stem(nb3,b3)
xlabel('Time')
ylabel('b3[n]')
title('Barker Length 3')

figure (2)
nb7=0:15;
b7=[1 1 -1 -1 1 -1 -1 zeros(1,9)];
stem(nb7,b7)
xlabel('Time')
ylabel('b7[n]')
title('Barker Length 7')

figure (3)
nb13=0:15;
b13=[1 1 -1 -1 1 -1 -1 1 1 1 -1 -1 1 zeros(1,3)];
stem(nb13,b13)
xlabel('Time')
ylabel('b13[n]')
title('Barker Length 13')

figure (4)
negnb3=fliplr(b3)
nb3=-15:15;
stem(nb3,negnb3)
xlabel=('Time')
ylabel=('b[-n]')
title('h_{MF}[n]')

figure(5)
nb3=-15:15;
y=conv(b3,negnb3);
stem(nb3,y)
label=('Time')
ylabel=('')
title('h_{MF}[n]')

